﻿namespace CongesSociaux_Web.Models
{
    public enum TypeEmploye
   
    {
       Soutien = 1,
       Enseignant = 2
    }
}
