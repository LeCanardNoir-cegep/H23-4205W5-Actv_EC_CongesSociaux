﻿namespace CongesSociaux_Web.Models
{
    public class Soutien: Employe
    {
        public string Poste { get; set; }
    }
}
